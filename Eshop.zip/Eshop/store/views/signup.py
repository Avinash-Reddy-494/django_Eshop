from django.shortcuts import redirect, render
from store.models import Customer
from django.contrib.auth.hashers import make_password
from django.views import View


class Signup(View):
    def get(self,request):
         return render(request,'signup.html')
    def post(self,request):
        first_name=request.POST.get("fname")
        last_name=request.POST.get("lname")
        mobile_number=request.POST.get("mobile")
        email=request.POST.get("email")
        password=request.POST.get("passwd1")
        value={
            'first_name':first_name,
            'last_name':last_name,
            'mobile_number':mobile_number,
            'email':email
        }
        error_msg=""
        customer=Customer(first_name=first_name,last_name=last_name,mobile_number=mobile_number,email=email,password=password)
        error_msg=self.validateCustomer(customer)
        if not error_msg:
            customer.password=make_password(customer.password)
            customer.register()
            return redirect('index')
        else:

            data={
                'error':error_msg,
                'values':value
            }
            return render(request,"signup.html",data)
    def validateCustomer(self,customer):
        error_msg=None;
        if(not customer.first_name):
         error_msg="Fisrt_name Required!"
        elif len(customer.first_name)<4:
            error_msg="First name must be 4 char long or more!"
        elif(not customer.last_name):
            error_msg="Last_name Required!"
        elif len(customer.last_name)<4:
            error_msg="last name must be 4 char long or more!"
        elif (not customer.mobile_number):
            error_msg="Mobile number Required!"
        elif len(customer.mobile_number)<10:
            error_msg="Mobile number must be 10 digits!"
        elif len(customer.password)<6:
            error_msg="Password must be 5 char long!"
        elif len(customer.email)<5:
            error_msg="Email must be 5 char long!"
        isExists=customer.isEXist()
        if isExists:
            error_msg="Email already registered!!"
        return error_msg
