from django.shortcuts import redirect, render
from store.models import Customer, Product,Order
from django.views import View

class checkout(View):
    def post(self,request):
        address=request.POST.get('address')
        mobile=request.POST.get("phone")
        customer=request.session.get('customer')
        cart=request.session.get('cart')
        products=Product.get_products_by_id(list(cart.keys()))
        print(address,mobile,customer,products,cart)
        for product in products:
            order=Order(customer=Customer(id=customer),product=product,price=product.price,quantity=cart.get(str(product.id)),address=address,mobile=mobile)
            order.placeOrder();
        request.session["cart"]={}
        return redirect('cart')
