from django.shortcuts import redirect, render
from store.models import Product,Order
from django.views import View
from store.middlewares.auth import Auth_middleware

class orders(View):
   
    def get(self,request):
        customer=request.session.get("customer")
        orders=Order.get_all_orders(customer)
        print(orders)
    
        return render(request,'orders.html',{'products':orders})
