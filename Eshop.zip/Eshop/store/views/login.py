from django.shortcuts import redirect, render,HttpResponseRedirect
from store.models import Customer
from django.contrib.auth.hashers import check_password
from django.views import View

class Login(View):
    return_url=None
    def get(self,request):
        Login.return_url=request.GET.get('return_Url')
        return render(request,'login.html')
    def post(self,request):
        email=request.POST.get('email')
        password=request.POST.get('passwd1')
        error_msg=None;
        customer=Customer.get_customer_by_email(email)
        print(customer)
        if customer:
            flag=check_password(password,customer.password)
            if flag:
                request.session['customer']=customer.id
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url=None
                    return redirect('index')
            else:
                
                error_msg="Password is incorrect"
                data={
                'error':error_msg,
                'values':email
            }

        else:
            error_msg="Email is Invalid"
            data={
                'error':error_msg
            }
        return render(request,'login.html',{'error':error_msg,'values':email})
def logout(request):
    request.session.clear()
    return redirect('login')