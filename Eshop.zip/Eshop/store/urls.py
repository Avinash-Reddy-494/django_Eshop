from django.urls import path
from .views import login,signup,index,cart,checkout,orders
from store.middlewares.auth import Auth_middleware
urlpatterns = [
    path('',index.index.as_view(),name="index"),
    path('signup',signup.Signup.as_view(),name="signup"),
    path('login',login.Login.as_view(),name="login"),
    path('logout',login.logout,name="logout"),
    path('cart',cart.Cart.as_view(),name="cart"),
    path('checkout',checkout.checkout.as_view(),name="checkout"),
    path('orders',Auth_middleware(orders.orders.as_view()),name="orders")
]
